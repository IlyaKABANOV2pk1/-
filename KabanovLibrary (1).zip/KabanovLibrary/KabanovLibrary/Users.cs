﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KabanovLibrary
{
    public class Users
    {
        public string _name;
        public string _email;
        public string _password;

        public string Name
        {
            get => _name;
            set => _name = value;
        }
        public string Email
        {
            get => _email;
            set => _email = value;
        }
        public string Password
        {
            get => _password;
            set => _password = value;
        }
        public Users() { }

        public Users(string name, string email, string password)
        { 
            this._name = name;
            this._email = email;
            this._password = password;
        }

        public Users(string email, string password)
        {
            this._email = email;
            this._password = password;
        }

        public override string ToString()
        {
            return $"{Name} : {Email} : {Password}";
        }



    }
}
