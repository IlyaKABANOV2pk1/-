﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KabanovLibrary
{
    public class Appointments
    {
        public string _user;
        public string _appointment;
        public string _time;


        public string User
        {
            get => _user;
            set => _user = value;
        }
        public string Time
        {
            get => _time;
            set => _time = value;
        }
        public string Appointment
        {
            get => _appointment;
            set => _appointment = value;
        }

        /// <summary>
        /// для корректной десиреализации обязательно
        /// должен присутствовать конструктор без параметров
        /// </summary>
        public Appointments() { }
        public Appointments(string user, string time, string appointment)
        {
            this._user = user;
            this._time = time;
            this._appointment = appointment;
        }
        public override string ToString()
        {
            return $"{Time} : {User} : {Appointment}";
        }
    }
}
