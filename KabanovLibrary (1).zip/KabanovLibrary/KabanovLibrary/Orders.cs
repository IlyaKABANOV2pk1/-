﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KabanovLibrary
{
    public class Orders : IComparable<Orders>
    {
        public string _name;

        public string Name
        {
            get => _name;
            set => _name = value;
        }
        
        public Orders() { }

        public Orders(string name)
        {
            this._name = name;

        }
        public int CompareTo(Orders other)
        {
            return _name.CompareTo(other._name);   // сравнение по названию
        }
        public override string ToString()
        {
            return $"{Name}";
        }

    }
}
