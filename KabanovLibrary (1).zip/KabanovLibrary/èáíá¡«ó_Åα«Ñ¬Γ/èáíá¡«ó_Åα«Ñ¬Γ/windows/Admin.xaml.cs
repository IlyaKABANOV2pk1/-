﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Кабанов_Проект.windows
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        private List<KabanovLibrary.Orders> _orders; //список услуг
        private const string _jsonFilePath = "orders.json"; //путь к файлу сохранения
        private List<KabanovLibrary.Appointments> _appointments; //список заказов
        private const string _jsonFilePath2 = "appointments.json"; //путь к файлу сохранения

        public Admin()
        {
            InitializeComponent();
            _orders = new List<KabanovLibrary.Orders>(); //инициализация списка услуг
            _appointments = new List<KabanovLibrary.Appointments>(); //инициализация списка заказов
            Orders.ItemsSource = _orders; //к списку главного окна привязывается источник данных - коллекция услуг
            Appointments.ItemsSource = _appointments; //к списку главного окна привязывается источник данных - коллекция заказов
        }

        /// <summary>
        /// Добавление услуги
        /// </summary>
        private void Add_Order(object sender, RoutedEventArgs e)
        {
            AddOrder addOrder = new AddOrder(this); //отображение окна
            addOrder.Show();

            //подписка на событие добавления заказов в дочернем окне
            addOrder.OrdersAddEvent += delegate (object senser, KabanovLibrary.Orders orders)
            {
                _orders.Add(orders);
                _orders.Sort(); // применение icomporable из библиотеки
                Orders.Items.Refresh(); //обновления списка в окне 

            };

        }

        /// <summary>
        /// Добавление заказа
        /// </summary>
        private void Add_Appointment(object sender, RoutedEventArgs e)
        {
            AddAppointment addAppointment = new AddAppointment(this); //отображение окна
            addAppointment.Show();
            addAppointment.Combobox.ItemsSource = _orders;

            //подписка на событие добавления заказов в дочернем окне
            addAppointment.AppointmentsAddEvent += delegate (object senser, KabanovLibrary.Appointments appointment)
            {
                _appointments.Add(appointment);
                Appointments.Items.Refresh(); //обновления списка в окне 


            };

        }


        #region события окна: открытие/закрытие окна, нажатие кнопок

        /// <summary>
        /// событие загрузки окна - загружаются данные из файла
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDataFromJson();
        }

        /// <summary>
        /// события закрытия окна - сохраняются данные в файл
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            SaveDataToJson();
        }

        #endregion

        #region работа с файлом
        /// <summary>
        /// загрузка из файла и десериализация данных
        /// </summary>
        internal void LoadDataFromJson()
        {
            if (File.Exists(_jsonFilePath))
            {
                string serializationData = File.ReadAllText(_jsonFilePath); //считывание содержимого файла
                if (serializationData != null)
                {
                    var orders = JsonConvert.DeserializeObject<List<KabanovLibrary.Orders>>(serializationData); //десериализация содержимого файла и запись в список задач
                    foreach (var order in orders)
                    {
                        _orders.Add(order);
                    }
                }

            }
            if (File.Exists(_jsonFilePath2))
            {
                string serializationData = File.ReadAllText(_jsonFilePath2); //считывание содержимого файла
                if (serializationData != null)
                {
                    var appointments = JsonConvert.DeserializeObject<List<KabanovLibrary.Appointments>>(serializationData); //десериализация содержимого файла и запись в список задач
                    foreach (var appointment in appointments)
                    {
                        _appointments.Add(appointment);
                    }
                }

            }
        }

        /// <summary>
        /// сериализация и сохранение данных в файл
        /// </summary>
        internal void SaveDataToJson()
        {
            // !!!
            _orders.Sort(); // применение интерфейса icomporable из библиотеки
            // !!!
            if (!File.Exists(_jsonFilePath))
            {
                File.Create(_jsonFilePath).Close();
            }
            string serializationData = JsonConvert.SerializeObject(_orders);
            File.WriteAllText(_jsonFilePath, serializationData);

            if (!File.Exists(_jsonFilePath2))
            {
                File.Create(_jsonFilePath2).Close();
            }
            string serializationData2 = JsonConvert.SerializeObject(_appointments);
            File.WriteAllText(_jsonFilePath2, serializationData2);

        }

        #endregion
        /// <summary>
        /// Удаление заказов, можно удалить сразу несколько
        /// </summary>
        private void Delete_Appointment(object sender, RoutedEventArgs e)
        {
            // Получаем выделенные элементы из ListBox
            var selectedItems = Appointments.SelectedItems.Cast<KabanovLibrary.Appointments>().ToList();

            // Удаляем выделенные элементы из списка заказов
            foreach (var item in selectedItems)
            {
                _appointments.Remove(item);
            }

            // Обновляем отображение ListBox
            Appointments.ItemsSource = null;
            Appointments.ItemsSource = _appointments;
        }

        /// <summary>
        /// Удаление услуг, можно удалить сразу несколько
        /// </summary>
        private void Delete_Order(object sender, RoutedEventArgs e)
        {
            // Получаем выделенные элементы из ListBox
            var selectedItems = Orders.SelectedItems.Cast<KabanovLibrary.Orders>().ToList();

            // Удаляем выделенные элементы из списка заказов
            foreach (var item in selectedItems)
            {
                _orders.Remove(item);
            }

            // Обновляем отображение ListBox
            Orders.ItemsSource = null;
            Orders.ItemsSource = _orders;
        }
    }
}
