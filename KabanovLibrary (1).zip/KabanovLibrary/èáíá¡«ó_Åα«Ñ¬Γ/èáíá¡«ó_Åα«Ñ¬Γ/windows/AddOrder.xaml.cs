﻿using KabanovLibrary;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Кабанов_Проект.windows
{
    /// <summary>
    /// Логика взаимодействия для AddAdmin.xaml
    /// </summary>
    public partial class AddOrder : Window
    {
        internal event EventHandler<KabanovLibrary.Orders> OrdersAddEvent; //событие добавления услуги

        internal void OnOrdersAddEvent(KabanovLibrary.Orders orders) // OnAppointmentsAddEvent
        {
            OrdersAddEvent?.Invoke(this, orders);
        }

        public AddOrder(Window owner) // прошлое окно - владелец этого окна
        {
            InitializeComponent();
            this.Owner = owner;
        }

        /// <summary>
        /// Добавление услуги
        /// </summary>
        private void Add_Order(object sender, RoutedEventArgs e) 
        {
            string s = name.Text;
            OnOrdersAddEvent(new KabanovLibrary.Orders(s)); ;
            this.Close();
        }

        /// <summary>
        /// Закрытие окна
        /// </summary>
        private void Exit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}
