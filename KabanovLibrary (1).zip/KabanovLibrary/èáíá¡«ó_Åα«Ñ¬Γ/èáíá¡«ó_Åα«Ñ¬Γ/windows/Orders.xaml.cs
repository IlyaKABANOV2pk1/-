﻿using KabanovLibrary;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Кабанов_Проект.windows
{
    /// <summary>
    /// Логика взаимодействия для Orders.xaml
    /// </summary>
    public partial class Orders : Window
    {
        private List<KabanovLibrary.Appointments> _appointments; //список заказов
        private const string _jsonFilePath = "appointments.json"; //путь к файлу сохранения
        public Orders()
        {
            InitializeComponent();
            _appointments = new List<KabanovLibrary.Appointments>(); //инициализация списка заказов
        }

        private void Add_Appointment(object sender, RoutedEventArgs e)
        {
            AddAppointment addAppointment = new AddAppointment(this); //создание окна для добавления заказа
            addAppointment.Show(); //отображение окна
                                   //подписка на событие добавления заказов в дочернем окне
            addAppointment.AppointmentsAddEvent += delegate (object senser, KabanovLibrary.Appointments appointment)
            {
                _appointments.Add(appointment);
            };

        }


        #region события окна: открытие/закрытие окна, нажатие кнопок

        /// <summary>
        /// событие загрузки окна - загружаются данные из файла
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDataFromJson();
        }

        /// <summary>
        /// события закрытия окна - сохраняются данные в файл
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            SaveDataToJson();
        }

        #endregion

        #region работа с файлом
        /// <summary>
        /// загрузка из файла и десериализация данных
        /// </summary>
        internal void LoadDataFromJson()
        {
            if (File.Exists(_jsonFilePath))
            {
                string serializationData = File.ReadAllText(_jsonFilePath); //считывание содержимого файла
                if (serializationData != null)
                {
                    var appointments = JsonConvert.DeserializeObject<List<KabanovLibrary.Appointments>>(serializationData); //десериализация содержимого файла и запись в список задач
                    foreach (var appointment in appointments)
                    {
                        _appointments.Add(appointment);
                    }
                }

            }
        }
        /// <summary>
        /// сериализация и сохранение данных в файл
        /// </summary>
        internal void SaveDataToJson()
        {
            if (!File.Exists(_jsonFilePath))
            {
                File.Create(_jsonFilePath).Close();
            }
            string serializationData = JsonConvert.SerializeObject(_appointments);
            File.WriteAllText(_jsonFilePath, serializationData);
        }
        #endregion

        /// <summary>
        /// Вернуться на главное окно
        /// </summary>
        private void Button_Back(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }

}