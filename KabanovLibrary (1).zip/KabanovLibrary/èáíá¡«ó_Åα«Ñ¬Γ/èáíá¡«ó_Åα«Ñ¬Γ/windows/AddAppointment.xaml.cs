﻿using KabanovLibrary;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Кабанов_Проект.windows
{
    /// <summary>
    /// Логика взаимодействия для AddAppointment.xaml
    /// </summary>
    public partial class AddAppointment : Window
    {
        private List<KabanovLibrary.Orders> _orders; //список услуг
        private const string _jsonFilePath = "orders.json"; //путь к файлу сохранения

        /// <summary>
        /// Событие добавления заказа
        /// </summary>
        internal event EventHandler<KabanovLibrary.Appointments> AppointmentsAddEvent;

        internal void OnAppointmentsAddEvent(KabanovLibrary.Appointments appointment) // OnAppointmentsAddEvent
        {
            AppointmentsAddEvent?.Invoke(this, appointment);
        }

        public AddAppointment(Window owner) // владелец этого окна - открытое окно до этого
        {
            InitializeComponent();
            _orders = new List<KabanovLibrary.Orders>(); //инициализация списка заказов
            this.Owner = owner;
            Combobox.ItemsSource = _orders; // заполнение списка услуг
        }

        /// <summary>
        /// Добавление заказа по нажатию кнопки
        /// </summary>
        private void Add_Appointment(object sender, RoutedEventArgs e) // добавление заказа, идет в основное окно
        {
            string s = Combobox.SelectedItem.ToString();
            OnAppointmentsAddEvent(new KabanovLibrary.Appointments(NameSurname.Text, DateTime.Text, s));
            this.Close();
        }

        /// <summary>
        /// Закрытие окна
        /// </summary>
        private void Exit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        #region события окна: открытие для загрузки обьектов в ComboBox

        /// <summary>
        /// событие загрузки окна - загружаются данные из файла
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDataFromJson();
        }

        #endregion

        #region работа с файлом json, нужно для заполнения ComboBox
        /// <summary>
        /// загрузка из файла и десериализация данных
        /// </summary>
        internal void LoadDataFromJson()
        {
            if (File.Exists(_jsonFilePath))
            {
                string serializationData = File.ReadAllText(_jsonFilePath); //считывание содержимого файла
                if (serializationData != null)
                {
                    var orders = JsonConvert.DeserializeObject<List<KabanovLibrary.Orders>>(serializationData); //десериализация содержимого файла и запись в список задач
                    foreach (var order in orders)
                    {
                        _orders.Add(order);
                    }
                }

            }
        }
        #endregion
    }
}
